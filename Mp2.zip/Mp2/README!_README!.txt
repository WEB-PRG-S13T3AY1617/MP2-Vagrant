Notes:
-Click "New Beginnings MarketPlace" to go back to all posts
-Only 10 posts per page (cannot get posts_per_page to increase)
-No Log Out
-Cannot get registered user as foreign key for Item model, resorted to drop down
-Cannot get coursecode to disappear when office is selected
-No tags and no search function
-Cannot get degree/office to show in User Profile